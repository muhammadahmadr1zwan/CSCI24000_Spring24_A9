import java.io.Serializable;

public interface Attribute extends Serializable {
    int getValue();
    void incrementValue();
    void decrementValue();
}
