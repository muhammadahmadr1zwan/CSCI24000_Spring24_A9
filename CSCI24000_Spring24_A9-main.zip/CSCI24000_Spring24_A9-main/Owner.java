import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Owner implements Serializable {
    private List<Pet> pets;
    private static final long serialVersionUID = 3L;

    public Owner() {
        pets = new ArrayList<>();
    }

    public void addPet(Pet pet) {
        pets.add(pet);
    }

    public int getPetsCount() {
        return pets.size();
    }

    public void interactWithPet(int petIndex) {
        if (petIndex < 0 || petIndex >= pets.size()) {
            System.out.println("Invalid pet index.");
            return;
        }

        Pet pet = pets.get(petIndex);
        Scanner scanner = new Scanner(System.in);
        boolean interacting = true;

        while (interacting) {
            System.out.println("\nChoose an action for " + pet.getName() + ":");
            System.out.println("1. Play\n2. Feed\n3. Make Sound\n4. Perform Unique Action\n5. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    pet.play();
                    break;
                case 2:
                    pet.feed();
                    break;
                case 3:
                    pet.makeSound();
                    break;
                case 4:
                    pet.performUniqueAction();
                    break;
                case 5:
                    interacting = false;
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    public void listPets() {
        if (pets.isEmpty()) {
            System.out.println("No pets added yet.");
            return;
        }

        System.out.println("\nYour pets:");
        for (int i = 0; i < pets.size(); i++) {
            System.out.println(i + ": " + pets.get(i).getName());
        }
    }
}
