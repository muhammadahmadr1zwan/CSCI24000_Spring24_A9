// HappinessAttribute.java
public class HappinessAttribute implements Attribute {
    private int value;

    public HappinessAttribute() {
        this.value = 100; // Assume maximum happiness by default
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public void incrementValue() {
        if (value < 100) {
            value++;
        }
    }

    @Override
    public void decrementValue() {
        if (value > 0) {
            value--;
        }
    }
}
