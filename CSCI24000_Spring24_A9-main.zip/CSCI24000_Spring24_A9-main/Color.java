// Color.java
public enum Color {
    RED,
    BLUE,
    GREEN,
    YELLOW,
    ORANGE,
    PURPLE,
    WHITE,
    BLACK,
    BROWN,
    PINK
}
