import java.util.Random;

public class Bird implements Pet {
    private Attribute happiness;
    private Attribute hunger;
    private Color color;
    private String name;
    private int age;
    private String description;
    private String favoriteToy;

    public Bird(Color color, String name) {
        this.happiness = new HappinessAttribute();
        this.hunger = new HungerAttribute();
        this.color = color;
        this.name = name;
        this.age = 1;
        this.description = "";
        this.favoriteToy = "";
    }

    @Override
    public void play() {
        System.out.println(name + " chirps and flutters joyfully.");
        happiness.incrementValue();
        hunger.incrementValue();
        printIndicator();
    }

    @Override
    public void feed() {
        System.out.println(name + " pecks at seeds.");
        happiness.decrementValue();
        hunger.decrementValue();
        printIndicator();
    }

    @Override
    public void makeSound() {
        System.out.println(name + " sings beautifully.");
        happiness.incrementValue();
        hunger.incrementValue();
        printIndicator();
    }

    @Override
    public Attribute getAttribute1() {
        return happiness;
    }

    @Override
    public Attribute getAttribute2() {
        return hunger;
    }

    @Override
    public Color getColor() {
        return color;
    }

    @Override
    public void rest() {
        System.out.println(name + " rests on a perch.");
    }

    @Override
    public void sleep() {
        System.out.println(name + " goes to sleep.");
    }

    @Override
    public boolean isTired() {
        return false; // Assume birds don't get tired
    }

    @Override
    public boolean isHungry() {
        return hunger.getValue() > 50;
    }

    @Override
    public boolean isHappy() {
        return happiness.getValue() > 70;
    }

    @Override
    public boolean needsAttention() {
        Random random = new Random();
        return random.nextDouble() < 0.1; // 10% chance of needing attention
    }

    @Override
    public boolean isAsleep() {
        return false; // Assume birds don't sleep
    }

    @Override
    public void checkHealth() {
        System.out.println(name + "'s health is checked by a veterinarian.");
    }

    @Override
    public boolean isHealthy() {
        return true; // Assume birds are healthy by default
    }

    @Override
    public void takeToVet() {
        System.out.println(name + " is taken to the vet for a checkup.");
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int getAge() {
        return age;
    }

    @Override
    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public void learnNewTrick(String trickName) {
        System.out.println(name + " learns a new trick: " + trickName);
    }

    @Override
    public void performTrick(String trickName) {
        System.out.println(name + " performs trick: " + trickName);
    }

    @Override
    public String getFavoriteToy() {
        return favoriteToy;
    }

    @Override
    public void setFavoriteToy(String toyName) {
        this.favoriteToy = toyName;
        System.out.println(name + " now has a new favorite toy: " + toyName);
    }

    @Override
    public void interactWithOtherPet(Pet otherPet) {
        System.out.println(name + " interacts with " + otherPet.getName() + ".");
    }

    @Override
    public void receiveAffection() {
        happiness.incrementValue();
        System.out.println(name + " chirps happily in response to affection.");
    }

    @Override
    public String makeUniqueSound() {
        return "Cheerful chirping";
    }

    @Override
    public void performUniqueAction() {
        System.out.println(name + " shows off its colorful feathers.");
    }

    @Override
    public void celebrateBirthday() {
        age++;
        System.out.println(name + " is now " + age + " years old. Happy Birthday!");
    }

    private void printIndicator() {
        System.out.println("Happiness level: " + happiness.getValue());
        System.out.println("Hunger level: " + hunger.getValue());
    }
}
