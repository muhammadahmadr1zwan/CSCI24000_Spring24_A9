import java.io.Serializable;
import java.util.Random;

public interface Pet extends Serializable {
    void play();
    void feed();
    void makeSound();
    Attribute getAttribute1();
    Attribute getAttribute2();
    Color getColor();
    void rest();
    void sleep();
    boolean isTired();
    boolean isHungry();
    boolean isHappy();
    boolean needsAttention();
    boolean isAsleep();
    void checkHealth();
    boolean isHealthy();
    void takeToVet();
    String getName();
    void setName(String name);
    int getAge();
    void setAge(int age);
    String getDescription();
    void setDescription(String description);
    void learnNewTrick(String trickName);
    void performTrick(String trickName);
    String getFavoriteToy();
    void setFavoriteToy(String toyName);
    void interactWithOtherPet(Pet otherPet);
    void receiveAffection();
    String makeUniqueSound();
    void performUniqueAction();
    void celebrateBirthday();
    default void leaveSubform() {
    System.out.println("Leaving subform.");
}

}
