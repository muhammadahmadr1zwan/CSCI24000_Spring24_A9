import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Select a pet
        System.out.println("Choose a Pet to interact with:");
        System.out.println("1- Fish");
        System.out.println("2- Bird");
        int petChoice = scanner.nextInt();
        Pet pet;
        if (petChoice == 1) {
            pet = new Fish(Color.BLUE, "Nemo");
        } else {
            pet = new Bird(Color.YELLOW, "Tweety");
        }

        // Interact with the pet
        while (true) {
            System.out.println("\nChoose from the following:");
            System.out.println("1- play");
            System.out.println("2- feed");
            System.out.println("3- make sound");
            System.out.println("4- view color");
            System.out.println("5- view hunger value");
            System.out.println("6- view happiness value");
            System.out.println("7- Exit");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    pet.play();
                    break;
                case 2:
                    pet.feed();
                    break;
                case 3:
                    pet.makeSound();
                    break;
                case 4:
                    System.out.println("Color: " + pet.getColor());
                    break;
                case 5:
                    System.out.println("Hunger level: " + pet.getAttribute1().getValue());
                    break;
                case 6:
                    System.out.println("Happiness level: " + pet.getAttribute2().getValue());
                    break;
                case 7:
                    pet.leaveSubform(); // Exit the pet interaction
                    return;
                default:
                    System.out.println("Invalid choice!");
                    break;
            }
        }
    }
}
