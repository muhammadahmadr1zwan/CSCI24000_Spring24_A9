// HungerAttribute.java
public class HungerAttribute implements Attribute {
    private int value;

    public HungerAttribute() {
        this.value = 0; // Assume no hunger by default
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public void incrementValue() {
        if (value < 100) {
            value++;
        }
    }

    @Override
    public void decrementValue() {
        if (value > 0) {
            value--;
        }
    }
}
